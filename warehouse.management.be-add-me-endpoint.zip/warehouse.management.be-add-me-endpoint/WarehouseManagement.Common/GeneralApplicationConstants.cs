﻿namespace WarehouseManagement.Common;

public static class GeneralApplicationConstants
{
    public const string ApiAssemblyName = "WarehouseManagement.Api";
}
