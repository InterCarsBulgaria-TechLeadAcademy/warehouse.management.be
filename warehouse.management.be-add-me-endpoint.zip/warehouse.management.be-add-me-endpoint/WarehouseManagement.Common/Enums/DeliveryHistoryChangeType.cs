﻿namespace WarehouseManagement.Common.Enums;

public enum DeliveryHistoryChangeType
{
    Delivery,
    Entry
}
