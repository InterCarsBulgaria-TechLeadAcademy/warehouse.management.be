﻿namespace WarehouseManagement.Common.ValidationConstants;

public static class ZoneConstants
{
    public const int NameMinLength = 1;
    public const int NameMaxLength = 500;
}
