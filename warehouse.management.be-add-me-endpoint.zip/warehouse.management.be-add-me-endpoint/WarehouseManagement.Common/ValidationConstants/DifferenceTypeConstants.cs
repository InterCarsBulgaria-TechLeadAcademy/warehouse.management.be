﻿namespace WarehouseManagement.Common.ValidationConstants;

public static class DifferenceTypeConstants
{
    public const int NameMaxLenght = 250;
    public const int NameMinLenght = 1;
}
