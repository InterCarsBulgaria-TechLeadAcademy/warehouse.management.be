﻿namespace WarehouseManagement.Common.ValidationConstants
{
    public static class MarkerConstants
    {
        public const int NameMaxLenght = 100;
        public const int NameMinLenght = 2;
    }
}
