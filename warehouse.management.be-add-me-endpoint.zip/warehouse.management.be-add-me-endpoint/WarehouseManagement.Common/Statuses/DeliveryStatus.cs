﻿namespace WarehouseManagement.Common.Statuses;

public enum DeliveryStatus
{
    Waiting,
    Processing,
    Finished,
    Approved
}
