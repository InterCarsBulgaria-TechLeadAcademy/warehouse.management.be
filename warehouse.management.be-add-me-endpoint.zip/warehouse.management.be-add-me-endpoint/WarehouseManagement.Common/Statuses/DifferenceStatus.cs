﻿namespace WarehouseManagement.Common.Statuses;

public enum DifferenceStatus
{
    Waiting,
    Processing,
    Finished,
    NoDifferences
}
