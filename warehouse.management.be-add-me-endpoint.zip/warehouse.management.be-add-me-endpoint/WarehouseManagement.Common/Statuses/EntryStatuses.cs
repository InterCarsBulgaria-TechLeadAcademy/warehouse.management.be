﻿namespace WarehouseManagement.Common.Statuses
{
    public enum EntryStatuses
    {
        Waiting,
        Processing,
        Finished
    }
}
