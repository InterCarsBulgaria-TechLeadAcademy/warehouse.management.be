﻿namespace WarehouseManagement.Common.MessageConstants.Keys;

public static class ApplicationUserMessageKeys
{
    public const string UserWithThisIdNotFound = "UserWithThisIdNotFound"; 
}
