﻿namespace WarehouseManagement.Api.Services.Contracts
{
    public interface IUserService
    {
        string UserId { get; }
    }
}
