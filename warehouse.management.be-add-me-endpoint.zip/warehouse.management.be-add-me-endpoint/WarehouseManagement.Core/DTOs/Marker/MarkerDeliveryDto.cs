﻿namespace WarehouseManagement.Core.DTOs.Marker;

public class MarkerDeliveryDto
{
    public int DeliveryId { get; set; }
    public string DeliverySystemNumber { get; set; } = string.Empty;
}
