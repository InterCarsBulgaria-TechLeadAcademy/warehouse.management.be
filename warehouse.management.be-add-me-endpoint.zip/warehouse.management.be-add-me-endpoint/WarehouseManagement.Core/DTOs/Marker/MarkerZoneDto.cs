﻿namespace WarehouseManagement.Core.DTOs.Marker;

public class MarkerZoneDto
{
    public int ZoneId { get; set; }
    public string ZoneName { get; set; } = string.Empty;
}
