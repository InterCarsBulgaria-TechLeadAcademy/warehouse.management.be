﻿namespace WarehouseManagement.Core.DTOs.Role;

public class RoleUserAssignDto
{
    public string Id { get; set; } = string.Empty;

    public string UserId { get; set; } = string.Empty;
}
