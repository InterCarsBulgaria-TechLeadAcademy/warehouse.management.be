﻿namespace WarehouseManagement.Core.DTOs.Delivery;

public class DeliveryMarkerDto
{
    public int MarkerId { get; set; }

    public string MarkerName { get; set; } = string.Empty;
}
