﻿namespace WarehouseManagement.Core.DTOs.Entry;

public class EntrySplitDto
{
    public int NewZoneId { get; set; }

    public int Count { get; set; }
}
