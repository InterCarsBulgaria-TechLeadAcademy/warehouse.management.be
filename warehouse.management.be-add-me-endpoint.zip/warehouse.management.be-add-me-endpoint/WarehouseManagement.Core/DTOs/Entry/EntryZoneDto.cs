namespace WarehouseManagement.Core.DTOs.Entry;

public class EntryZoneDto
{
    public string ZoneName { get; set; }
    public bool IsFinal { get; set; }
}