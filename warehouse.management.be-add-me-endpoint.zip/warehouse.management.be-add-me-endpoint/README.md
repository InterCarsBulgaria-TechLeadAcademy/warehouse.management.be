# warehouse.management.be
I test rules
